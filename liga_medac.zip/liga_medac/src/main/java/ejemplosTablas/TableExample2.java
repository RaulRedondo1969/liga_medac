/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplosTablas;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;

/**
 *
 * @author usuario
 */
public class TableExample2 {
    public static void main(String[] a) {  
            JFrame f = new JFrame("Table Example");  
            String data[][]={ {"101","Amit","670000"},    
                              {"102","Jai","780000"},    
                              {"101","Sachin","700000"}};    
                            String column[]={"ID","NAME","SALARY"};         
                            final JTable jt=new JTable(data,column);    
            jt.setCellSelectionEnabled(true);  
            ListSelectionModel select= jt.getSelectionModel();  //Le pasamos el Modelo del DataTable al selectionModel
            select.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
            //Esta pendiente del Evento de selección de la lista
            select.addListSelectionListener((ListSelectionEvent e) -> {
                String Data = null;
                int[] row = jt.getSelectedRows();
                int[] columns = jt.getSelectedColumns();
                for (int i = 0; i < row.length; i++) {
                    for (int j = 0; j < columns.length; j++) {
                        Data = (String) jt.getValueAt(row[i], columns[j]);
                    } }
                System.out.println("Table element selected is: " + Data);       
            });  
            JScrollPane sp=new JScrollPane(jt);    // La vista del ScrollPanel es la tabla. 
            f.add(sp);  
            f.setSize(300, 200);  
            f.setVisible(true);  
          }  
    
}
