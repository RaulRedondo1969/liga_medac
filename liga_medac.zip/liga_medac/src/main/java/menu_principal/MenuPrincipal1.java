/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menu_principal;

/**
 *
 * @author usuario
 */


import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

//import crud_jugadores.PanelAltaJugadores;


public class MenuPrincipal1 extends JFrame {

 
 //private final JPanel contentPane;


 public static void main(String[] args) {
  EventQueue.invokeLater(() -> {
      try {
         
          MenuPrincipal1 frame = new MenuPrincipal1();
          frame.setVisible(true);
      } catch (Exception e) {
      }
  });
 }


 public MenuPrincipal1() {

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(200, 200, 450, 300);
    JMenuBar menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    JMenu mnJugadores = new JMenu("Jugadores");
    menuBar.add(mnJugadores);
    JMenuItem itemAltaJugadores = new JMenuItem("Alta de Jugadores");
    mnJugadores.add(itemAltaJugadores);
    itemAltaJugadores.addMouseListener(new MouseAdapter() {
    @Override
       public void mousePressed(MouseEvent e) {
       //PanelAltaJugadores panelAltaJugadores = new PanelAltaJugadores();
       //setTitle("Liga Medac. Alta de Jugadores");
   }
  });

  // aquí termina la barra de menú ...
  
  

}



}
