/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * https://dev.mysql.com/doc/connector-j/8.0/en/connector-j-overview.html
 * @author usuario
 */
public class Conexion {
    private static Logger logConexion = Logger.getLogger("conexion");
    private static Connection conexion; 
    private static String host; 
    private static String user;
    private static String password;
    
    public static Connection conectar() throws ClassNotFoundException, SQLException{
        host = "localhost:3306/liga_medac";
        user = "root";
        password = "12345";
        CargarDriver.cargarDriver();
        //Class.forName("com.mysql.cj.jdbc.Driver");//clase deprecated
        conexion = DriverManager.getConnection("jdbc:mysql://" + host + "?" + "user=" + user + "&password=" + password );
        if (conexion.isClosed()){
            logConexion.info("No Se ha establecido la conexión");
        }
        else {
            logConexion.info("Se ha estalecido la conexión");
        }
        return conexion;
        
       }
    
    public static void cerrarConexion() throws SQLException{
        
         if (conexion.isClosed()){
             logConexion.info("La conexión no esta abierta");
         }
        else {
             conexion.close();
             logConexion.info("Se ha cerrado la conexion");
         }
    }
}
