/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jugadores;

/**
 *
 * @author usuario
 */
public class Demarcacion {
    
    private String nombre_demarcacion;

    public String getNombre_demarcacion() {
        return nombre_demarcacion;
    }

    public void setNombre_demarcacion(String nombre_demarcacion) {
        this.nombre_demarcacion = nombre_demarcacion;
    }
    
    
    
}
