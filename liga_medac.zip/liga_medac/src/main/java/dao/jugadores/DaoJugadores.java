/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.jugadores;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import utilidades.Conexion;

/**
 *
 * @author usuario
 */
public class DaoJugadores {
    private static JTable tabla;
    private static JFrame ventana;
    private static JScrollPane scroll;
    
       public static void creaYMuestraVentana()
    {
        ventana = new JFrame("Contenido base de datos");
        if (tabla == null)
            tabla = new JTable();
        scroll = new JScrollPane(tabla);
        ventana.getContentPane().add(scroll);
        ventana.pack();
        ventana.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        ventana.setVisible(true);
    }
    
    //Atención que el metodo devuelve un Resultset
    public static ResultSet DaoJugadores() throws ClassNotFoundException, SQLException{
        Connection conexion = Conexion.conectar();
        Statement verJugadores = conexion.createStatement();
        ResultSet rs = verJugadores.executeQuery("select * from jugadores");
        creaYMuestraVentana();
        DefaultTableModel tbModel = new DefaultTableModel();
        tabla.setModel(tbModel);
       
        while(rs.next()){
            Object [] fila = new Object[3];
            for (int i =0; i < fila.length;i++){
                fila[i]= rs.getObject(i+1);
                tbModel.addRow(fila);
            }
        }
        return rs;
        
    }

    
    
}
