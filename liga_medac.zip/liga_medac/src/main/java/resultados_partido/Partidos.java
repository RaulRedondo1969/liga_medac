/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package resultados_partido;

import arbitro.Arbitro;
import equipos.Equipos;
import java.time.LocalDate;
import java.util.List;
import jugadores.Jugadores;
import parte_lesionados.ParteDeLesionados;

/**
 *
 * @author usuario
 */
public class Partidos {
    private int nJornada;//1-n
    private String resultado; 
    private int golesVistante; 
    private int golesLocal;
    private List<Arbitro> listaArbitros; 
    private List<Jugadores> alineacionLocal;
    private List<Jugadores> alineacionVisitante; 
    private Equipos equipoLocal; 
    private Equipos equipoVisitante; 
    private LocalDate fecha_partido;
    private List<ParteDeLesionados> parteLesionados;

    public Partidos(int nJornada, String resultado, int golesVistante, int golesLocal, List<Arbitro> listaArbitros, List<Jugadores> alineacionLocal, List<Jugadores> alineacionVisitante, Equipos equipoLocal, Equipos equipoVisitante, LocalDate fecha_partido, List<ParteDeLesionados> parteLesionados) {
        this.nJornada = nJornada;
        this.resultado = resultado;
        this.golesVistante = golesVistante;
        this.golesLocal = golesLocal;
        this.listaArbitros = listaArbitros;
        this.alineacionLocal = alineacionLocal;
        this.alineacionVisitante = alineacionVisitante;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.fecha_partido = fecha_partido;
        this.parteLesionados = parteLesionados;
    }
    
    

    public Partidos(int nJornada, String resultado, int golesVistante, int golesLocal, List<Arbitro> listaArbitros, List<Jugadores> alineacionLocal, List<Jugadores> alineacionVisitante, Equipos equipoLocal, Equipos equipoVisitante, LocalDate fecha_partido) {
        this.nJornada = nJornada;
        this.resultado = resultado;
        this.golesVistante = golesVistante;
        this.golesLocal = golesLocal;
        this.listaArbitros = listaArbitros;
        this.alineacionLocal = alineacionLocal;
        this.alineacionVisitante = alineacionVisitante;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.fecha_partido = fecha_partido;
    }

    public List<ParteDeLesionados> getParteLesionados() {
        return parteLesionados;
    }

    public void setParteLesionados(List<ParteDeLesionados> parteLesionados) {
        this.parteLesionados = parteLesionados;
    }

    
    public int getnJornada() {
        return nJornada;
    }

    public void setnJornada(int nJornada) {
        this.nJornada = nJornada;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public int getGolesVistante() {
        return golesVistante;
    }

    public void setGolesVistante(int golesVistante) {
        this.golesVistante = golesVistante;
    }

    public int getGolesLocal() {
        return golesLocal;
    }

    public void setGolesLocal(int golesLocal) {
        this.golesLocal = golesLocal;
    }

    public List<Arbitro> getListaArbitros() {
        return listaArbitros;
    }

    public void setListaArbitros(List<Arbitro> listaArbitros) {
        this.listaArbitros = listaArbitros;
    }

    public List<Jugadores> getAlineacionLocal() {
        return alineacionLocal;
    }

    public void setAlineacionLocal(List<Jugadores> alineacionLocal) {
        this.alineacionLocal = alineacionLocal;
    }

    public List<Jugadores> getAlineacionVisitante() {
        return alineacionVisitante;
    }

    public void setAlineacionVisitante(List<Jugadores> alineacionVisitante) {
        this.alineacionVisitante = alineacionVisitante;
    }

    public Equipos getEquipoLocal() {
        return equipoLocal;
    }

    public void setEquipoLocal(Equipos equipoLocal) {
        this.equipoLocal = equipoLocal;
    }

    public Equipos getEquipoVisitante() {
        return equipoVisitante;
    }

    public void setEquipoVisitante(Equipos equipoVisitante) {
        this.equipoVisitante = equipoVisitante;
    }

    public LocalDate getFecha_partido() {
        return fecha_partido;
    }

    public void setFecha_partido(LocalDate fecha_partido) {
        this.fecha_partido = fecha_partido;
    }
    
    
    
}
