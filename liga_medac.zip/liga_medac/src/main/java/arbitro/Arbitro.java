/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbitro;

import persona.Persona;

/**
 *
 * @author usuario
 */
public class Arbitro extends Persona {
    
    private int nColegiado; 

    public Arbitro(int nColegiado, String nombre, String apellido, String dni) {
        super(nombre, apellido, dni);
        this.nColegiado = nColegiado;
    }

    public int getnColegiado() {
        return nColegiado;
    }

    public void setnColegiado(int nColegiado) {
        this.nColegiado = nColegiado;
    }
    
    
    
}
