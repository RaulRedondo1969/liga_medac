/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesiones;

import java.time.LocalDate;

/**
 *
 * @author usuario
 */
public class Lesion {
    private String nombreLesion; 
    private String gravedad;
    private LocalDate fechaLesion; 
    private LocalDate fechaAltaLesion; 

    public Lesion(String nombreLesion, String gravedad, LocalDate fechaLesion, LocalDate fechaAltaLesion) {
        this.nombreLesion = nombreLesion;
        this.gravedad = gravedad;
        this.fechaLesion = fechaLesion;
        this.fechaAltaLesion = fechaAltaLesion;
    }

    public String getNombreLesion() {
        return nombreLesion;
    }

    public void setNombreLesion(String nombreLesion) {
        this.nombreLesion = nombreLesion;
    }

    public String getGravedad() {
        return gravedad;
    }

    public void setGravedad(String gravedad) {
        this.gravedad = gravedad;
    }

    public LocalDate getFechaLesion() {
        return fechaLesion;
    }

    public void setFechaLesion(LocalDate fechaLesion) {
        this.fechaLesion = fechaLesion;
    }

    public LocalDate getFechaAltaLesion() {
        return fechaAltaLesion;
    }

    public void setFechaAltaLesion(LocalDate fechaAltaLesion) {
        this.fechaAltaLesion = fechaAltaLesion;
    }
    
    
}
