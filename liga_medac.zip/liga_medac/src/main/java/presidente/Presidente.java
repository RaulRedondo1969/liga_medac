/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presidente;

import persona.Persona;



/**
 *
 * @author usuario
 */
public class Presidente extends Persona{
    
private int idPresidente; 
private int aniosCargo; 

    public Presidente(int idPresidente, int añosCargo, String nombre, String apellido, String dni) {
        super(nombre, apellido, dni);
        this.idPresidente = idPresidente;
        this.aniosCargo = añosCargo;
    }

    public int getIdPresidente() {
        return idPresidente;
    }

    public void setIdPresidente(int idPresidente) {
        this.idPresidente = idPresidente;
    }

    public int getAñosCargo() {
        return aniosCargo;
    }

    public void setAñosCargo(int añosCargo) {
        this.aniosCargo = añosCargo;
    }



    
 

  

    
  

    
    

    

 
    
}
