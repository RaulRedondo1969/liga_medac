/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menus;

/**
 *
 * @author usuario
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import pruebas_jdbc.Panel;

// la clase principal
public class Principal extends JFrame {

 // el panel que todo lo contiene
 private JPanel contentPane;

 // la entrada al programa, lo que primero
 // se ejecuta
 public static void main(String[] args) {
  EventQueue.invokeLater(() -> {
      try {
          // crea el frame en memoria
          // y lo visualiza
          Principal frame = new Principal();
          frame.setVisible(true);
      } catch (Exception e) {
      }
  });
 }

 // ésto es el constructor de la clase
 // aquí está todo
 public Principal() {

  // al cerrar la ventana sale del programa
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  // dimensiones y posición al arrancar del JFrame
  setBounds(200, 200, 450, 300);

  // JMenuBar, es la que aparece arriba
  JMenuBar menuBar = new JMenuBar();
  setJMenuBar(menuBar); // Inicializamos en el constructor nuestra barra de menus

  // EL MENU JUGADORES EMPIEZA AQUÍ ---------------------------------------
  JMenu mnJugadores = new JMenu("Jugadores");
  //Le añadimos nuestro menuJugadores a la barra de menus
  menuBar.add(mnJugadores);
  // LOS JMenuItem DEL MENU JUGADORES--------------------------------------
  JMenuItem itmAltaJugadores = new JMenuItem("Alta de Jugadores");
  //Se añade el Menu Item al MENU JUGADORES
  mnJugadores.add(itmAltaJugadores);
  //Se le añade un evento de Mouse
  itmAltaJugadores.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
       Panel p1 = new Panel();
       
    setTitle("Liga Medac. Alta de Jugadores"
            + "");
   }
  });
  //Los JSeparator
  /*JSeparator separatorAltaJugadores = new JSeparator();
  mnJugadores.add(separatorAltaJugadores);*/
  
  //AL MENU JUGADORES se le añade el ITEM de Menu Baja de Jugadores
  JMenuItem itmBajaJugadores = new JMenuItem("Baja Jugadores");
  mnJugadores.add(itmBajaJugadores);
  itmBajaJugadores.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    setTitle("Liga Medac. Baja de Jugadores"
            + "");
   }
  });
  //Los JSeparator
  /*JSeparator separatorBajaJugadores = new JSeparator();
  mnJugadores.add(separatorBajaJugadores);*/
  
  //AL MENU JUGADORES se le añade el ITEM de Menu Actualizar de Jugadores
  JMenuItem itmActualizarJugadores = new JMenuItem("Actualizar Jugadores");
  mnJugadores.add(itmActualizarJugadores);
  itmActualizarJugadores.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
       
      
    setTitle("Liga Medac. Actualizar Jugadores"
            + "");
   }
  });
  //AL MENU JUGADORES se le añade el ITEM de Menu Ver Jugadores
  JMenuItem itmVerJugadores = new JMenuItem("Ver Jugadores");
  mnJugadores.add(itmVerJugadores);
  itmVerJugadores.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    setTitle("Liga Medac. Ver Jugadores"
            + "");
   }
  });
  
  
  
  
  
  
  
  
  //EL JMENU ARBITROS EMPIEZA AQUÍ
  JMenu mnArbitros = new JMenu("Arbitros");
  menuBar.add(mnArbitros);
  
  // AL MENU JUGADORES LE PONEMOS EL ITEM SALIR
  JMenuItem mntmSalir_1 = new JMenuItem("Salir");
  mntmSalir_1.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    dispose();
   }
  });
  // Es una linea que nos sirve para separar....UN SEPARATOR
  JSeparator separator_1 = new JSeparator();
  mnJugadores.add(separator_1);
  mnJugadores.add(mntmSalir_1);
  // CHECK BOX ITEM
  //Le colocamos un Checkbox de menu item
 // JCheckBoxMenuItem chckbxmntmUnJcheckboxmenuitem = new JCheckBoxMenuItem(
   // "Un JCheckBoxMenuItem");
  //mnJugadores.add(chckbxmntmUnJcheckboxmenuitem);
   //Le colocamos un Radio button Checkbox de menu item
   // RADIO BUTTON ITEM
  /*JRadioButtonMenuItem rdbtnmntmUnJradiobuttonmenuitem = new JRadioButtonMenuItem(
    "Un JRadioButtonMenuItem");*/
 // mnJugadores.add(rdbtnmntmUnJradiobuttonmenuitem);
 //Le colocamos otro Radio button Checkbox de menu item
 /* JRadioButtonMenuItem rdbtnmntmOtroJradiobuttonmenuitem = new JRadioButtonMenuItem(
    "Otro JRadioButtonMenuItem");
  mnJugadores.add(rdbtnmntmOtroJradiobuttonmenuitem);*/
  //Aqui estamos añadiendo el JMenuItem de salir
 

  // el menú Colores empieza aquí ---------------------------------------
  /*JMenu mnColores = new JMenu("Colores");
  //Añadimos a nuestra barra de Menus otro JMenu
  menuBar.add(mnColores);

  JMenuItem mntmBlanco = new JMenuItem("Blanco");
  mntmBlanco.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    contentPane.setBackground(Color.WHITE);
   }
  });
  //Añadimos el menuItemBlanco al Menu
  mnColores.add(mntmBlanco);

  JMenuItem mntmNegro = new JMenuItem("Negro");
  mntmNegro.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    contentPane.setBackground(Color.BLACK);
   }
  });
  mnColores.add(mntmNegro);

  JMenu mnCambiarElColor = new JMenu(
    "Cambiar el color de fondo con otros colores");
  mnColores.add(mnCambiarElColor);

  JMenuItem mntmVerde = new JMenuItem("Verde");
  mntmVerde.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    contentPane.setBackground(Color.GREEN);
   }
  });
  mnCambiarElColor.add(mntmVerde);

  JMenuItem mntmRojo = new JMenuItem("Rojo");
  mntmRojo.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    contentPane.setBackground(Color.RED);
   }
  });
  mnCambiarElColor.add(mntmRojo);

  JMenuItem mntmAzul = new JMenuItem("Azul");
  mntmAzul.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    contentPane.setBackground(Color.BLUE);
   }
  });
  mnCambiarElColor.add(mntmAzul);*/

  // EL ITEM PARA MINIMIZAR ESTÁ AQUÍ ---------------------------------------
  JMenuItem mntmNewMenuItem = new JMenuItem("Minimizar");
  menuBar.add(mntmNewMenuItem);
  mntmNewMenuItem.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    setState(Frame.ICONIFIED);
   }
  });
  
  // aquí termina la barra de menú ...
  
  
  // el panel que todo lo contiene se crea
  contentPane = new JPanel();
  // se le pone un borde
  contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
  // se establece en el JFrame
  setContentPane(contentPane);

  // se hace JPopupMenu y lo pongo en el panel contenedor
  //Son menus ocultos
  JPopupMenu popupMenu = new JPopupMenu();
  popupMenu.setBounds(0, 0, 319, 58);
  addPopup(contentPane, popupMenu);

  // el primer elemento del desplegable del JPopupMenu
  JMenuItem mntmhola = new JMenuItem("Hola!");
  popupMenu.add(mntmhola);

  // el segundo elemento del desplegable
  JMenuItem mntmfelizNavidad = new JMenuItem("u00A1Feliz Navidad!");
  popupMenu.add(mntmfelizNavidad);
  
  // el resto del JPanel con la raya separadora y la etiqueta explicatoria  
  contentPane.setLayout(null);

  JSeparator separator = new JSeparator();
  separator.setBounds(31, 88, 372, 24);
  contentPane.add(separator);

  JLabel lblHazClickCon = new JLabel(
    "Haz click con el botón derecho en la ventana para que salga el menu.");
  lblHazClickCon.setBounds(10, 118, 414, 76);
  contentPane.add(lblHazClickCon);
 }

 // ésto es lo relativo al menú desplegable
 // lo que hace es mostrar éste menú donde sea que hagamos click 
 private static void addPopup(Component component, final JPopupMenu popup) {
  component.addMouseListener(new MouseAdapter() {
   @Override
   public void mousePressed(MouseEvent e) {
    if (e.isPopupTrigger()) {
     showMenu(e);
    }
   }

   @Override
   public void mouseReleased(MouseEvent e) {
    if (e.isPopupTrigger()) {
     showMenu(e);
    }
   }

   private void showMenu(MouseEvent e) {
    popup.show(e.getComponent(), e.getX(), e.getY());
   }
  });
 }
}
