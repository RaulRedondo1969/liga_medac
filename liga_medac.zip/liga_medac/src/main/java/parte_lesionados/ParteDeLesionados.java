/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parte_lesionados;

import java.time.LocalDate;
import java.util.List;
import jugadores.Jugadores;
import lesiones.Lesion;
import medico.Medico;

/**
 *
 * @author usuario
 */
public class ParteDeLesionados {
    
    private int n_parte; 
    private LocalDate fecha_parte; 
    private Jugadores njugador; 
    private List<Lesion> lesiones;
    private List<Medico> medicos;

    public ParteDeLesionados(int n_parte, LocalDate fecha_parte, Jugadores njugador, List<Lesion> lesiones, List<Medico> medicos) {
        this.n_parte = n_parte;
        this.fecha_parte = fecha_parte;
        this.njugador = njugador;
        this.lesiones = lesiones;
        this.medicos = medicos;
    }

    public int getN_parte() {
        return n_parte;
    }

    public void setN_parte(int n_parte) {
        this.n_parte = n_parte;
    }

    public LocalDate getFecha_parte() {
        return fecha_parte;
    }

    public void setFecha_parte(LocalDate fecha_parte) {
        this.fecha_parte = fecha_parte;
    }

    public Jugadores getNjugador() {
        return njugador;
    }

    public void setNjugador(Jugadores njugador) {
        this.njugador = njugador;
    }

    public List<Lesion> getLesiones() {
        return lesiones;
    }

    public void setLesiones(List<Lesion> lesiones) {
        this.lesiones = lesiones;
    }

    public List<Medico> getMedicos() {
        return medicos;
    }

    public void setMedicos(List<Medico> medicos) {
        this.medicos = medicos;
    }
    
    
    

    
}
