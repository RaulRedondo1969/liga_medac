/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipos;


import java.time.LocalDate;
import java.util.List;
import presidente.Presidente;


/**
 *
 * @author usuario
 */
public class Equipos {
    private String nombreEquipo; //1-1
    private LocalDate fechaFundacion;
    private List<Presidente> listaPresidentes; 
    private Presidente nombrePresidente;

    public Equipos(String nombreEquipo, LocalDate fechaFundacion, List<Presidente> listaPresidentes) {
        this.nombreEquipo = nombreEquipo;
        this.fechaFundacion = fechaFundacion;
        this.listaPresidentes = listaPresidentes;
    }
    
    

    public Equipos(String nombreEquipo, LocalDate fechaFundacion, Presidente nombrePresidente) {
        this.nombreEquipo = nombreEquipo;
        this.fechaFundacion = fechaFundacion;
        this.nombrePresidente = nombrePresidente;
    }

    
    
    
    
    public Presidente getNombrePresidente() {
        return nombrePresidente;
    }

    public void setNombrePresidente(Presidente nombrePresidente) {
        this.nombrePresidente = nombrePresidente;
    }
    


    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public LocalDate getFechaFundacion() {
        return fechaFundacion;
    }

    public void setFechaFundacion(LocalDate fechaFundacion) {
        this.fechaFundacion = fechaFundacion;
    }

    public List<Presidente> getListaPresidentes() {
        return listaPresidentes;
    }

    public void setListaPresidentes(List<Presidente> listaPresidentes) {
        this.listaPresidentes = listaPresidentes;
    }
    
    
    
}
